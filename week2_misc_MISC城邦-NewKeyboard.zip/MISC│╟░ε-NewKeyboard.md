## MISC城邦-NewKeyboard 

题目附件给了usb键盘流量`字符对照表`和`NewKeyboard.pcapng`

我们先看字符对照表`abcdefghijklmnopqrstuvwxyz1234567890-_!{}.pcapng`确定每一个字符

可以使用`tshark`将`usbhid.data`字段导出，方便进行分析

```
tshark.exe -r "abcdefghijklmnopqrstuvwxyz1234567890-_!{}.pcapng" -T fields -e usbhid.data > 1.txt
```

<img src=".\MISC城邦-NewKeyboard.assist\1.png" alt="image-20251112023316931"  />

可以看出使用shift键是0102，其他则是0100开头，我们按照对应内容去写映射脚本

写脚本之前，我们先将`newkeyboard.pcapng`的`usbhid.data`字段按照刚才的方式同样提取出来

```
tshark.exe -r newkeyboard.pcapng -T fields -e usbhid.data > 2.txt
```

#注意，这里我去掉了换行

![image-20251125033557521](.\MISC城邦-NewKeyboard.assist\2.png)

然后我们可以开始编写脚本，这里为了新生们方便理解，用了大量的if

```
with open('2.txt', 'r') as f:
    lines = f.readlines()
mapping1 = {"10":"a","20":"b","40":"c","80":"d"}   #[4:6]
mapping2 = {"01":"e","02":"f","04":"g","08":"h","10":"i","20":"j","40":"k","80":"l"} #[6:8]
mapping3 = {"01":"m","02":"n","04":"o","08":"p","10":"q","20":"r","40":"s","80":"t"} #[8:10]
mapping4 = {"01":"u","02":"v","04":"w","08":"x","10":"y","20":"z","40":"1","80":"2"} #[10:12]
mapping5 = {"01":"3","02":"4","04":"5","08":"6","10":"7","20":"8","40":"9","80":"0"} #[12:14]
mapping6 = {"20":"-"} #[14:16]
smapping1 = {"20":"_","80":"{"} #[14:16]
smapping2 = {"40":"!"} #[10:12]
smapping3 = {"01":"}"} #[16:18]

flag = []

for i in range(len(lines)):
    txt = lines[i]
    if txt[4:6] != '00' or txt[6:8] != '00' or txt[8:10] != '00' or txt[10:12] != '00' or txt[12:14] != '00' or txt[14:16] != '00' or txt[16:18] != '00':
        if txt[0:4] == '0100' :
            if txt[4:6] in mapping1 :
                flag += mapping1[txt[4:6]]
            elif txt[6:8] in mapping2 :
                flag += mapping2[txt[6:8]]
            elif txt[8:10] in mapping3 :
                flag += mapping3[txt[8:10]]
            elif txt[10:12] in mapping4 :
                flag += mapping4[txt[10:12]]
            elif txt[12:14] in mapping5 :
                flag += mapping5[txt[12:14]]
            elif txt[14:16] in mapping6 :
                flag += mapping6[txt[14:16]]
        elif txt[0:4] == '0102':
            if txt[14:16] in smapping1 :
                flag += smapping1[txt[14:16]]
            elif txt[10:12] in smapping2 :
                flag += smapping2[txt[10:12]]
            elif txt[16:18] in smapping3 :
                flag += smapping3[txt[16:18]]
print("".join(flag))
```

运行脚本后即可得到flag