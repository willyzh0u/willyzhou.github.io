## 应急响应-把你mikumiku掉-1

我们查看tomcat的版本信息，可以得到，版本号为`9.0.98`

![image-20251204151130988](.\应急响应-把你mikumiku掉-1.assist\1.png)

我们搜索`tomcat9.0.98 cve`可以搜索到编号为`CVE-2025-24813`的历史漏洞

![image-20251204151406896](.\应急响应-把你mikumiku掉-1.assist\2.png)

结合日志，可以确定使用的cve

```
cat localhost_access_log.2025-10-17.txt
```

![image-20251204151859911](.\应急响应-把你mikumiku掉-1.assist\3.png)

**CVE-2025-24813**

