## 区块链-INTbug

 在 `usePoints()` 函数的 `unchecked` 代码块中： 

```
unchecked {
    totalPoints -= points;
    userSpentPoints[msg.sender] -= points;
}
```

**初始状态**：每个用户调用 `addPoints()` 或 `usePoints()` 时，如果 `userSpentPoints[msg.sender]` 为0，会被设置为1000。

如果满足uncheckd下方判断，则会触发解锁

```
if (userSpentPoints[msg.sender] > 1000) {
	unlocked[msg.sender] = true;
}
```

也就是说，只要使用的点数大于1000，就可以触发解锁

我们在`addPsoints`中输入大于1000的数，`addPoints`执行后再进行`usePoints`大于1000的数即可

![image-20251204145914684](.\区块链-INTbug.assist\1.png)

点击`getFlag`，即可得到flag

