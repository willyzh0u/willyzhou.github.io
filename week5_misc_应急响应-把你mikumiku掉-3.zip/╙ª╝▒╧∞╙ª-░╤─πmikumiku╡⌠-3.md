## 应急响应-把你mikumiku掉-3

我们进入的`/home/mikuu`，可以看到恶意程序和被加密的`flag.miku`

![image-20251204154251571](.\应急响应-把你mikumiku掉-3.assist\1.png)

我们使用ftp将文件传到本地，用ida打开`mikumikud`进行分析

![image-20251204154952149](.\应急响应-把你mikumiku掉-3.assist\2.png)

可以很清楚的看出这是一个aes加密的程序，我们分析key和iv即可写解密脚本

```
AES_set_encrypt_key(v13, 128LL, v10)
```

可以得出`v13`数组为key，但要注意小端序低字节在前，所以key为

```
12 34 56 78 9A BC DE F0 11 22 33 44 55 66 77 88
```

IV来自`ptr`和`v12`变量：

```
unsigned __int64 ptr; // [rsp+930h] [rbp-50h]
__int64 v12; // [rsp+938h] [rbp-48h]
ptr = 0xEF40511401811919LL;
v12 = 0x1032547698BADCFELL;
```

在加密过程中，iv被写入文件前面

```
fwrite(&ptr, 1uLL, 0x10uLL, s);  // 写入16字节：ptr(8字节) + v12(8字节)
```

知道key和iv后，编写脚本运行即可还原flag

```
from Crypto.Cipher import AES

key = bytes.fromhex('123456789ABCDEF01122334455667788')
with open('flag.miku', 'rb') as f:
    iv = f.read(16)
    ciphertext = f.read()

cipher = AES.new(key, AES.MODE_CBC, iv)
plaintext = cipher.decrypt(ciphertext)
pad_len = plaintext[-1]
print(plaintext)
```

