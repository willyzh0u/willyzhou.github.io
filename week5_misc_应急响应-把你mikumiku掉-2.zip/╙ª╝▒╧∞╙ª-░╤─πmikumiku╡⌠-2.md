## 应急响应-把你mikumiku掉-2

结合上题的日志，可以得知`mikuu.jsp`，我们查看`mikuu.jsp`

![image-20251204152545494](.\应急响应-把你mikumiku掉-2.assist\1.png)

可以分析出该木马连接密码为`miiikuuu`

我们查看`/etc/shadow`文件，可以看到一个名为`mikuu`的用户

![image-20251204152818054](.\应急响应-把你mikumiku掉-2.assist\2.png)

可以从`$y`中得知他是`yescrypt`密码

该类型的密码无法使用`hashcat`，而`john`的效率太低，我们在github上可以看到 [yescrypt_crack](https://github.com/cyclone-github/yescrypt_crack/releases/tag/v0.2.0) 项目

我们配完go环境，装依赖，再go bulid，根据tips，我们生成由miku四个字符构成的密码本

```
./yescrypt_crack.exe -h hash.txt -w ezdict.txt  -t 16 -s 10
```

爆破得到miiiku

