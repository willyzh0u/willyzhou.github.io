## OSINT-威胁情报

题目给了一个恶意情报的hash值，我们可以借助公开的威胁情报中心来完成此题

这里我使用的是`奇安信威胁情报中心`和`VirusTotal`

题目需要我们找到关于恶意文件的`apt组织名称`、`通信C2服务器域名`、`恶意文件编译时间(年-月-日)` 

**apt组织名称**

奇安信威胁情报中心：

在首页我们就可以直接得到攻击组织的名称

![image-20251107030045830](.\OSINT-威胁情报.assist\1.png)

VirusTotal：

在Family labels中显示多个标签，我们可以在社区进行进一步的确定

![image-20251107030345399](.\OSINT-威胁情报.assist\2.png)

在社区中，通过其他检测人员的确认确定apt家族名称

![image-20251107030832585](C:\Users\HUAWEI\Desktop\newstar_writewp\week2_misc_OSINT-威胁情报\OSINT-威胁情报.assist\3.png)



**通信C2服务器域名**

奇安信威胁情报中心：

我们需要点击`样本分析详情`得到动态运行的详细内容

![image-20251107031150478](.\OSINT-威胁情报.assist\4.png)

在`网络行为`栏，我们可以得到域名

![image-20251107031350031](.\OSINT-威胁情报.assist\5.png)

VirusTotal：

在`BEHAVIOR` - `Activity Summary` - `Memory Patten Domains`中可以确定它的域名

![image-20251107031749139](.\OSINT-威胁情报.assist\6.png)



**恶意文件编译时间(年-月-日)**

奇安信威胁情报中心：

在`基本信息` -  `Exiftool文件元数据` -  `TimeStamp` 代表恶意文件的编译时间

![image-20251107032018852](.\OSINT-威胁情报.assist\7.png)

 VirusTotal： 

在`DETAILS` - `History` - `Create Time` 可以得知编译时间

![image-20251107032144808](.\OSINT-威胁情报.assist\8.png)